#include "HelpfulClass.h"

void MyClass::hereIsAMethod() {
    // Implementation
}