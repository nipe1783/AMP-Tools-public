#include "AMPCore.h"

class MyClass {
    public:
        void hereIsAMethod();
};